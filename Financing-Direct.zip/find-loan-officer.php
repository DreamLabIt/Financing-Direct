<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Financing Direct | find-loan-officer</title>
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
   <link rel="stylesheet" href="./assets/css/final.css">
</head>

<body>
   <?php include 'header.php'; ?>
   <!-- hero section start -->
   <section class="hero-section">
      <div class="common-wrap d-flex justify-center item-center">
         <div class="content-wraper text-center">
            <p class="sub-title">Superior Service</p>
            <h1 class="title">Find a Loan Officer</h1>
            <p class="content">Want to work with the best loan officers in the country? Our loan officers are experienced and knowledgeable and provide the most exceptional service in the industry!</p>
            <div class="btn-wraper d-flex justify-center flex-wrap gap-20">
               <select class="btn" name="select state" id="">
                  <option value="bangladesh">Bangladesh</option>
                  <option value="bangladesh">Bangladesh</option>
                  <option value="bangladesh">Bangladesh</option>
                  <option value="bangladesh">Bangladesh</option>
                  <option value="bangladesh">Bangladesh</option>
               </select>
            </div>
         </div>
      </div>
   </section>
   <!-- hero section end -->
   <?php include 'footer-simple.php'; ?>
   <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

   <script src="./script.js"></script>
</body>

</html>