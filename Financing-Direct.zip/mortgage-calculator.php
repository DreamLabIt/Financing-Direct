<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>mortgage-calculator</title>
   <!-- <link rel="stylesheet" href="./assets/css/global.css"> -->
   <link rel="stylesheet" href="./assets/css/style.css">
   <!-- <link rel="stylesheet" href="./assets/css/responsive.css"> -->
</head>

<body class="about-shay">
   <?php include 'header.php'; ?>
   <!-- mortgage calculator section start -->
   <?php include "calculator.php"; ?>
   <?php include 'footer-simple.php'; ?>
   <!-- footer section end -->
   <script src="./script.js"></script>
</body>

</html>